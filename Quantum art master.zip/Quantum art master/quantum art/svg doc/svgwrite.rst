svgwrite module
===============

.. automodule:: svgwrite
