utils module
============

.. automodule:: svgwrite.utils
